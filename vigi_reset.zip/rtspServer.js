Stream1 = require("node-rtsp-stream");
stream1 = new Stream1({
  name: "Cam1",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.3:554/stream2",
  wsPort: 2,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});

Stream2 = require("node-rtsp-stream");
stream2 = new Stream2({
  name: "Cam2",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.16:554/stream2",
  wsPort: 3,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});

Stream3 = require("node-rtsp-stream");
stream3 = new Stream3({
  name: "Cam3",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.27:554/stream2",
  wsPort: 4,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});

Stream4 = require("node-rtsp-stream");
stream4 = new Stream4({
  name: "Cam4",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.15:554/stream2",
  wsPort: 5,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});

Stream5 = require("node-rtsp-stream");
stream5 = new Stream5({
  name: "Cam5",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.7:554/stream2",
  wsPort: 6,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});

Stream6 = require("node-rtsp-stream");
stream6 = new Stream6({
  name: "Cam6",
  streamUrl: "rtsp://admin:aaabbb000%2B%2B%2B@10.0.101.8:554/stream2",
  wsPort: 8,
  ffmpegOptions: {
    // options ffmpeg flags
    "-stats": "", // an option with no neccessary value uses a blank string
    "-r": 30, // options with required values specify the value after the key
  },
});
