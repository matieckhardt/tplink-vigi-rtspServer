const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const exphbs = require("express-handlebars");
const config = require("./config");
const path = require("path");
const flash = require("connect-flash");
const session = require("express-session");
const app = express();
const fs = require("fs");

app.set("PORT", config.PORT || 4000);
console.log(config.PORT);

app.set("secret", config.SK);
app.set("views", path.join(__dirname, "views"));
app.engine(
  ".hbs",
  exphbs.engine({
    layoutsDir: path.join(app.get("views"), "layouts"),
    partials: path.join(app.get("views"), "partials"),
    extname: ".hbs",
    defaultLayout: "main",
  })
);
app.set("view engine", ".hbs");

app.use(
  session({
    secret: "asd",
    resave: true,
    saveUninitialized: true,
  })
);
app.use(flash());

// global
app.use((req, res, next) => {
  res.locals.logData = req.flash("logData");
  next();
});

app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "public/dist")));
app.use(express.static(path.join(__dirname, "public/plugins")));
app.use(morgan("dev"));
app.use(cors());
app.use(express.json());
app.use(
  express.urlencoded({
    extended: false,
  })
);

// Ruta del index y carousel
app.get("/", function (req, res) {
  res.render("index");
});

app.get("/reset", function (req, res) {
  console.log("restarting");
  fs.writeFileSync("./resets.js", JSON.stringify([{ lastReset: new Date() }]));
  console.log("System rebooted");
  res.send("System Rebooted");
});

// RTSP SERVER

require("./rtspServer");

//FIN SERVER

module.exports = app;
